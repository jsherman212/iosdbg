#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv, const char **envp){
	printf("hello\n");
	return 0;
}
